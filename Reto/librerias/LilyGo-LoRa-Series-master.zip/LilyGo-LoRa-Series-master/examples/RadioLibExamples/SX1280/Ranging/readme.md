<h1 align = "center">🌟LilyGo LoRa Series🌟</h1>

1. Only LILYGO_T3_V1_8
2. Need to install the following dependencies(Add it to the '~/Arduino/libraries' directory)
    [SX12XX-LoRa](https://github.com/StuartsProjects/SX12XX-LoRa)



